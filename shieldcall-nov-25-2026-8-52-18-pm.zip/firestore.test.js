const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_1";
const BOB_UID = "bob_uid_2";
const ADMIN_UID = "admin_uid_0";
const ADMIN_EMAIL = "ubongn59@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastTime(offsetMs = 5000) {
  return new Date(Date.now() - offsetMs);
}

function futureTime() {
  return new Date(Date.now() + 120000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated context: cannot read or write any collection", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("caller_directory").where("visibility", "==", "PUBLIC").get());
  await assertFails(unauth.collection("spam_reports").where("status", "==", "APPROVED").get());
  await assertFails(unauth.collection("verified_businesses").where("verificationStatus", "==", "VERIFIED").get());
  await assertFails(unauth.collection("system_alerts").where("targetScope", "==", "ALL_USERS").get());
  await assertFails(
    unauth.collection("caller_directory").doc("18005550199").set({
      numberKey: "18005550199",
      displayNumber: "+1 800-555-0199",
      callerName: "Fake",
      category: "SCAM_FRAUD",
      verifiedBusiness: false,
      visibility: "PUBLIC",
      spamReportsCount: 1,
      safeReportsCount: 0,
      spamScore: 80,
      averageRating: 1.0,
      ratingsCount: 0,
      lastReportedTag: "SCAM_FRAUD",
      createdBy: ALICE_UID,
      createdAt: pastTime(),
      updatedAt: pastTime(),
    })
  );
});

test("User profile: owner create/read/update succeeds; role escalation & cross-user access fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const created = pastTime(10000);

  // Alice creates her own profile with USER role
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      phoneNumber: "+15550100",
      role: "USER",
      spamProtectionEnabled: true,
      autoBlockHighRisk: true,
      notificationsEnabled: true,
      themeMode: "SYSTEM",
      totalCallsScreened: 0,
      totalSpamBlocked: 0,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice updates preferences
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      autoBlockHighRisk: false,
      themeMode: "DARK",
      updatedAt: pastTime(1000),
    })
  );

  // Alice cannot escalate her own role to ADMIN
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "ADMIN",
      updatedAt: pastTime(500),
    })
  );

  // Alice cannot inject ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isSuperAdmin: true,
      updatedAt: pastTime(500),
    })
  );

  // Alice cannot tamper with future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Alice Future",
      updatedAt: futureTime(),
    })
  );

  // Bob cannot read, list, or update Alice's profile
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked", updatedAt: pastTime() }));
});

test("User subcollections (blocked_numbers & call_events): owner isolated CRUD and list", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = pastTime(10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("blocked_numbers").doc("18005550199").set({
      userId: ALICE_UID,
      phoneNumber: "18005550199",
      rawNumber: "+1 800-555-0199",
      label: "Robo Warranty",
      reason: "Persistent robocalls",
      blockMode: "REJECT",
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("blocked_numbers").doc("18005550199").update({
      blockMode: "SILENCE",
      updatedAt: pastTime(1000),
    })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("blocked_numbers").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("blocked_numbers").get());

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("call_events").doc("evt_1").set({
      userId: ALICE_UID,
      phoneNumber: "+18005550199",
      callerName: "Robo Warranty",
      callDirection: "BLOCKED",
      actionTaken: "BLOCKED",
      spamScore: 95,
      stirVerification: "FAILED",
      durationSeconds: 0,
      occurredAtMillis: Date.now() - 5000,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("call_events").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("call_events").get());
});

test("Caller directory & ratings: public query alignment, anti-spoofing, and admin verification", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const spoofedAdminDb = testEnv.authenticatedContext("spoof_uid", { email: ADMIN_EMAIL, email_verified: false }).firestore();
  const realAdminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();
  const created = pastTime(10000);

  // Non-admin cannot create pre-verified business entry
  await assertFails(
    aliceDb.collection("caller_directory").doc("18005550111").set({
      numberKey: "18005550111",
      displayNumber: "+1 800-555-0111",
      callerName: "Fake Bank",
      category: "VERIFIED_BUSINESS",
      verifiedBusiness: true,
      visibility: "PUBLIC",
      spamReportsCount: 0,
      safeReportsCount: 1,
      spamScore: 0,
      averageRating: 5.0,
      ratingsCount: 1,
      lastReportedTag: "VERIFIED_BUSINESS",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice creates valid unverified directory entry
  await assertSucceeds(
    aliceDb.collection("caller_directory").doc("18005550199").set({
      numberKey: "18005550199",
      displayNumber: "+1 800-555-0199",
      callerName: "Extended Auto Scam",
      category: "SCAM_FRAUD",
      verifiedBusiness: false,
      visibility: "PUBLIC",
      spamReportsCount: 1,
      safeReportsCount: 0,
      spamScore: 78,
      averageRating: 0.0,
      ratingsCount: 0,
      lastReportedTag: "SCAM_FRAUD",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Unfiltered directory query must fail; visibility-filtered query & non-existent doc get succeed
  await assertFails(bobDb.collection("caller_directory").get());
  await assertSucceeds(bobDb.collection("caller_directory").where("visibility", "==", "PUBLIC").get());
  await assertSucceeds(bobDb.collection("caller_directory").doc("19995550000").get());

  // Bob cannot flip verifiedBusiness to true
  await assertFails(
    bobDb.collection("caller_directory").doc("18005550199").update({
      verifiedBusiness: true,
      updatedAt: pastTime(500),
    })
  );

  // Spoofed admin with email_verified: false cannot verify
  await assertFails(
    spoofedAdminDb.collection("caller_directory").doc("18005550199").update({
      verifiedBusiness: true,
      updatedAt: pastTime(500),
    })
  );

  // Verified admin CAN verify or moderate directory entry
  await assertSucceeds(
    realAdminDb.collection("caller_directory").doc("18005550199").update({
      verifiedBusiness: false,
      spamScore: 96,
      updatedAt: pastTime(500),
    })
  );

  // Alice submits deterministic caller rating
  await assertSucceeds(
    aliceDb.collection("caller_ratings").doc(`18005550199_${ALICE_UID}`).set({
      userId: ALICE_UID,
      userName: "Alice",
      numberKey: "18005550199",
      stars: 1,
      review: "Fake warranty robocall",
      visibility: "PUBLIC",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice cannot write rating using Bob's UID key
  await assertFails(
    aliceDb.collection("caller_ratings").doc(`18005550199_${BOB_UID}`).set({
      userId: ALICE_UID,
      userName: "Alice",
      numberKey: "18005550199",
      stars: 5,
      review: "Spoof",
      visibility: "PUBLIC",
      createdAt: created,
      updatedAt: created,
    })
  );
});

test("Spam reports, verified businesses, system alerts, and admin registry", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();
  const created = pastTime(10000);

  // Alice submits PENDING spam report
  await assertSucceeds(
    aliceDb.collection("spam_reports").doc("rep_1").set({
      reporterId: ALICE_UID,
      reporterName: "Alice",
      numberKey: "18005550199",
      displayNumber: "+1 800-555-0199",
      reportedName: "IRS Impersonator",
      category: "IMPERSONATION",
      comment: "Demanded gift cards",
      status: "PENDING",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice cannot self-approve report
  await assertFails(
    aliceDb.collection("spam_reports").doc("rep_1").update({
      status: "APPROVED",
      updatedAt: pastTime(500),
    })
  );

  // Bob cannot list PENDING reports (only approved or his own)
  await assertFails(bobDb.collection("spam_reports").where("status", "==", "PENDING").get());
  await assertSucceeds(bobDb.collection("spam_reports").where("status", "==", "APPROVED").get());
  await assertSucceeds(aliceDb.collection("spam_reports").where("reporterId", "==", ALICE_UID).get());

  // Admin can list PENDING and approve
  await assertSucceeds(adminDb.collection("spam_reports").where("status", "==", "PENDING").get());
  await assertSucceeds(
    adminDb.collection("spam_reports").doc("rep_1").update({
      status: "APPROVED",
      reviewedBy: ADMIN_UID,
      updatedAt: pastTime(500),
    })
  );

  // Verified business application
  await assertSucceeds(
    aliceDb.collection("verified_businesses").doc("biz_1").set({
      ownerId: ALICE_UID,
      businessName: "Northstar Clinic",
      numberKey: "14155550120",
      displayNumber: "+1 415-555-0120",
      category: "Healthcare",
      website: "https://northstar.example.com",
      description: "Patient appointment line",
      verificationStatus: "PENDING",
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertFails(
    aliceDb.collection("verified_businesses").doc("biz_1").update({
      verificationStatus: "VERIFIED",
      updatedAt: pastTime(500),
    })
  );
  await assertSucceeds(
    adminDb.collection("verified_businesses").doc("biz_1").update({
      verificationStatus: "VERIFIED",
      updatedAt: pastTime(500),
    })
  );

  // System alerts: non-admin cannot create, signed-in can read ALL_USERS
  await assertFails(
    aliceDb.collection("system_alerts").doc("alert_1").set({
      title: "Fake Alert",
      message: "Unauthorized",
      severity: "CRITICAL",
      targetScope: "ALL_USERS",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    adminDb.collection("system_alerts").doc("alert_1").set({
      title: "Tax Scam Surge",
      message: "High volume of spoofed tax agency calls today.",
      severity: "CRITICAL",
      targetScope: "ALL_USERS",
      createdBy: ADMIN_UID,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(bobDb.collection("system_alerts").where("targetScope", "==", "ALL_USERS").get());
});
