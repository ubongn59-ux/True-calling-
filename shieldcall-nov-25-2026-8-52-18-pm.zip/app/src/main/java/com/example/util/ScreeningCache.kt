package com.example.util

import android.content.Context
import com.example.data.model.BlockedNumber
import com.example.data.model.CallerDirectoryEntry
import org.json.JSONArray
import org.json.JSONObject

data class CachedDirectoryMatch(
    val numberKey: String,
    val callerName: String,
    val category: String,
    val spamScore: Int,
    val verifiedBusiness: Boolean
)

data class PendingScreenedEvent(
    val phoneNumber: String,
    val callerName: String,
    val actionTaken: String,
    val spamScore: Int,
    val stirVerification: String,
    val occurredAtMillis: Long
)

class ScreeningCache(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var spamProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_PROTECTION_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECTION_ENABLED, value).apply()

    var autoBlockHighRisk: Boolean
        get() = prefs.getBoolean(KEY_AUTO_BLOCK_HIGH_RISK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_BLOCK_HIGH_RISK, value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply()

    fun syncBlockedNumbers(items: List<BlockedNumber>) {
        val mapJson = JSONObject()
        items.forEach { item ->
            val obj = JSONObject().apply {
                put("label", item.label)
                put("blockMode", item.blockMode)
            }
            mapJson.put(item.phoneNumber, obj)
        }
        prefs.edit().putString(KEY_BLOCKED_MAP, mapJson.toString()).apply()
    }

    fun getBlockedMode(numberKey: String): Pair<String, String>? {
        val raw = prefs.getString(KEY_BLOCKED_MAP, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val entry = root.optJSONObject(numberKey) ?: return null
            val label = entry.optString("label", "Blocked Caller")
            val mode = entry.optString("blockMode", "REJECT")
            label to mode
        } catch (_: Exception) {
            null
        }
    }

    fun syncDirectoryEntries(entries: List<CallerDirectoryEntry>) {
        val mapJson = JSONObject()
        entries.take(500).forEach { entry ->
            val obj = JSONObject().apply {
                put("callerName", entry.callerName)
                put("category", entry.category)
                put("spamScore", entry.spamScore.toInt())
                put("verifiedBusiness", entry.verifiedBusiness)
            }
            mapJson.put(entry.numberKey, obj)
        }
        prefs.edit().putString(KEY_DIRECTORY_MAP, mapJson.toString()).apply()
    }

    fun findDirectoryMatch(numberKey: String): CachedDirectoryMatch? {
        val raw = prefs.getString(KEY_DIRECTORY_MAP, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val obj = root.optJSONObject(numberKey) ?: return null
            CachedDirectoryMatch(
                numberKey = numberKey,
                callerName = obj.optString("callerName", "Unknown Caller"),
                category = obj.optString("category", "COMMUNITY"),
                spamScore = obj.optInt("spamScore", 0),
                verifiedBusiness = obj.optBoolean("verifiedBusiness", false)
            )
        } catch (_: Exception) {
            null
        }
    }

    fun enqueueScreenedEvent(event: PendingScreenedEvent) {
        val existingRaw = prefs.getString(KEY_PENDING_EVENTS, "[]") ?: "[]"
        val arr = try {
            JSONArray(existingRaw)
        } catch (_: Exception) {
            JSONArray()
        }
        val obj = JSONObject().apply {
            put("phoneNumber", event.phoneNumber)
            put("callerName", event.callerName)
            put("actionTaken", event.actionTaken)
            put("spamScore", event.spamScore)
            put("stirVerification", event.stirVerification)
            put("occurredAtMillis", event.occurredAtMillis)
        }
        arr.put(obj)
        prefs.edit().putString(KEY_PENDING_EVENTS, arr.toString()).apply()
    }

    fun drainPendingScreenedEvents(): List<PendingScreenedEvent> {
        val existingRaw = prefs.getString(KEY_PENDING_EVENTS, null) ?: return emptyList()
        prefs.edit().remove(KEY_PENDING_EVENTS).apply()
        return try {
            val arr = JSONArray(existingRaw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        PendingScreenedEvent(
                            phoneNumber = obj.optString("phoneNumber"),
                            callerName = obj.optString("callerName"),
                            actionTaken = obj.optString("actionTaken", "ALLOWED"),
                            spamScore = obj.optInt("spamScore", 0),
                            stirVerification = obj.optString("stirVerification", "NOT_VERIFIED"),
                            occurredAtMillis = obj.optLong("occurredAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private companion object {
        const val PREFS_NAME = "callshield_screening_cache"
        const val KEY_PROTECTION_ENABLED = "spam_protection_enabled"
        const val KEY_AUTO_BLOCK_HIGH_RISK = "auto_block_high_risk"
        const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        const val KEY_BLOCKED_MAP = "blocked_map_json"
        const val KEY_DIRECTORY_MAP = "directory_map_json"
        const val KEY_PENDING_EVENTS = "pending_screened_events"
    }
}
