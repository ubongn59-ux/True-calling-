package com.example.util

object PhoneNumberNormalizer {

    /**
     * Produces a deterministic, Firestore-document-ID-safe key (`^[a-zA-Z0-9_\-]+$`, length 3..24).
     */
    fun toKey(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return ""
        val trimmed = if (digits.length > 20) digits.takeLast(20) else digits
        return if (trimmed.length < 3) "num_$trimmed" else trimmed
    }

    /**
     * Formats phone numbers consistently for display.
     */
    fun formatDisplay(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return "Unknown"
        val digits = trimmed.filter { it.isDigit() }
        return when {
            digits.length == 10 -> "(${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6)}"
            digits.length == 11 && digits.startsWith("1") ->
                "+1 (${digits.substring(1, 4)}) ${digits.substring(4, 7)}-${digits.substring(7)}"
            trimmed.startsWith("+") -> trimmed
            digits.length >= 7 -> "+$digits"
            else -> trimmed
        }
    }

    fun isValidPhoneInput(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        return digits.length in 3..20
    }
}
