package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.VerifiedBusiness
import com.example.ui.components.CallerAvatar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SpamRiskBadge
import com.example.ui.components.VerifiedBusinessPill
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.util.PhoneNumberNormalizer

@Composable
fun LookupScreen(
    searchQuery: String,
    directory: List<CallerDirectoryEntry>,
    verifiedBusinesses: List<VerifiedBusiness>,
    onSearchQueryChange: (String) -> Unit,
    onInspectNumber: (String) -> Unit,
    onSubmitReport: (rawNumber: String, reportedName: String, category: String, comment: String) -> Unit
) {
    var showReportDialog by remember { mutableStateOf(false) }

    val cleanQuery = searchQuery.trim()
    val queryKey = PhoneNumberNormalizer.toKey(cleanQuery)

    val matchingEntries = remember(cleanQuery, queryKey, directory) {
        if (cleanQuery.isBlank()) {
            directory.take(30)
        } else {
            directory.filter { entry ->
                entry.callerName.contains(cleanQuery, ignoreCase = true) ||
                    entry.displayNumber.contains(cleanQuery, ignoreCase = true) ||
                    (queryKey.isNotEmpty() && entry.numberKey.contains(queryKey))
            }
        }
    }

    val matchingBusinesses = remember(cleanQuery, queryKey, verifiedBusinesses) {
        if (cleanQuery.isBlank()) {
            verifiedBusinesses
        } else {
            verifiedBusinesses.filter { biz ->
                biz.businessName.contains(cleanQuery, ignoreCase = true) ||
                    biz.category.contains(cleanQuery, ignoreCase = true) ||
                    biz.displayNumber.contains(cleanQuery, ignoreCase = true) ||
                    (queryKey.isNotEmpty() && biz.numberKey.contains(queryKey))
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search phone number or business...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(18.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            if (PhoneNumberNormalizer.isValidPhoneInput(cleanQuery)) {
                                onInspectNumber(cleanQuery)
                            }
                        }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("number_search_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onInspectNumber(cleanQuery) },
                            enabled = PhoneNumberNormalizer.isValidPhoneInput(cleanQuery),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("lookup_number_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Check Number")
                        }

                        OutlinedButton(
                            onClick = { showReportDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_report_dialog_button")
                        ) {
                            Icon(Icons.Filled.Flag, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Report Number")
                        }
                    }
                }
            }

            if (matchingBusinesses.isNotEmpty()) {
                item {
                    SectionHeader(title = "Verified Businesses")
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(matchingBusinesses, key = { it.id }) { biz ->
                            VerifiedBusinessCard(
                                business = biz,
                                onClick = { onInspectNumber(biz.displayNumber) }
                            )
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = if (cleanQuery.isBlank()) "Community Caller & Spam Index" else "Search Results (${matchingEntries.size})"
                )
            }

            if (matchingEntries.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = if (cleanQuery.isBlank()) "Directory Ready" else "No Exact Match Yet",
                        subtitle = if (PhoneNumberNormalizer.isValidPhoneInput(cleanQuery)) {
                            "Tap 'Check Number' above to inspect $cleanQuery, rate it, or submit the first community report."
                        } else {
                            "Search any phone number or report a suspicious caller to help protect the CallShield community."
                        },
                        ctaLabel = "Report a Number",
                        onCta = { showReportDialog = true }
                    )
                }
            } else {
                items(matchingEntries, key = { it.numberKey }) { entry ->
                    DirectoryEntryRow(
                        entry = entry,
                        onClick = { onInspectNumber(entry.displayNumber) }
                    )
                }
            }
        }
    }

    if (showReportDialog) {
        ReportSpamDialog(
            initialNumber = if (PhoneNumberNormalizer.isValidPhoneInput(cleanQuery)) cleanQuery else "",
            onDismiss = { showReportDialog = false },
            onSubmit = { rawNum, name, cat, comment ->
                onSubmitReport(rawNum, name, cat, comment)
                showReportDialog = false
            }
        )
    }
}

@Composable
private fun VerifiedBusinessCard(
    business: VerifiedBusiness,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(220.dp)
            .clickable(onClick = onClick)
            .testTag("verified_biz_card_${business.numberKey}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = "Verified Business",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = business.businessName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = business.category,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = business.displayNumber,
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DirectoryEntryRow(
    entry: CallerDirectoryEntry,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("directory_entry_${entry.numberKey}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CallerAvatar(
                name = entry.callerName,
                spamScore = entry.spamScore.toInt(),
                verifiedBusiness = entry.verifiedBusiness,
                isBlocked = false
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = entry.callerName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (entry.verifiedBusiness) VerifiedBusinessPill()
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${entry.displayNumber} • ${entry.category.replace("_", " ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (entry.ratingsCount > 0) {
                    Text(
                        text = "★ ${"%.1f".format(entry.averageRating)} (${entry.ratingsCount} reviews)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            SpamRiskBadge(
                spamScore = entry.spamScore.toInt(),
                verifiedBusiness = entry.verifiedBusiness,
                isBlocked = false
            )
        }
    }
}
