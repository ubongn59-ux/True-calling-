package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.BlockedNumber
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.DeviceContactItem
import com.example.ui.components.CallerAvatar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SpamRiskBadge
import com.example.ui.theme.JetBrainsMonoFamily

@Composable
fun ContactsScreen(
    contacts: List<DeviceContactItem>,
    directory: List<CallerDirectoryEntry>,
    blockedNumbers: List<BlockedNumber>,
    hasContactsPermission: Boolean,
    onRequestContactsPermission: () -> Unit,
    onInspectNumber: (String) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }

    val dirByKey = remember(directory) { directory.associateBy { it.numberKey } }
    val blockedKeys = remember(blockedNumbers) { blockedNumbers.map { it.phoneNumber }.toSet() }

    val filtered = remember(contacts, query) {
        val q = query.trim()
        if (q.isBlank()) contacts
        else contacts.filter {
            it.name.contains(q, ignoreCase = true) || it.phoneNumber.contains(q, ignoreCase = true)
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(title = "Device Contacts (${contacts.size})")
            }

            if (hasContactsPermission) {
                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Filter contacts by name or number") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Filter contacts") },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear filter")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("contacts_search_input")
                    )
                }
            }

            if (!hasContactsPermission) {
                item {
                    EmptyStateCard(
                        title = "Connect Your Contacts",
                        subtitle = "Allow CallShield to read your contacts so trusted friends and colleagues are always recognized alongside Verified Businesses.",
                        ctaLabel = "Allow Contacts Access",
                        onCta = onRequestContactsPermission
                    )
                }
            } else if (filtered.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "No Contacts Found",
                        subtitle = if (query.isBlank()) "Your device address book currently has no phone entries." else "No contacts matched \"$query\"."
                    )
                }
            } else {
                items(filtered, key = { it.id + "_" + it.numberKey }) { contact ->
                    val dir = dirByKey[contact.numberKey]
                    val isBlocked = contact.numberKey in blockedKeys
                    val spamScore = dir?.spamScore?.toInt() ?: 0
                    val verified = dir?.verifiedBusiness == true

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInspectNumber(contact.phoneNumber) }
                            .testTag("contact_row_${contact.numberKey}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CallerAvatar(
                                name = contact.name,
                                spamScore = spamScore,
                                verifiedBusiness = verified,
                                isBlocked = isBlocked
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${contact.phoneNumber} • ${contact.label}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isBlocked || spamScore >= 35 || verified) {
                                SpamRiskBadge(
                                    spamScore = spamScore,
                                    verifiedBusiness = verified,
                                    isBlocked = isBlocked
                                )
                            }
                            IconButton(
                                onClick = {
                                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}"))
                                    context.startActivity(dialIntent)
                                },
                                modifier = Modifier.testTag("dial_contact_${contact.numberKey}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Call,
                                    contentDescription = "Call ${contact.name}",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
