package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SystemAlert
import com.example.data.model.UnifiedCallRecord
import com.example.data.model.UserProfile
import com.example.ui.components.CallerAvatar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SpamRiskBadge
import com.example.ui.components.SystemAlertBanner
import com.example.ui.components.VerifiedBusinessPill
import com.example.ui.components.formatRelativeTime
import com.example.ui.theme.JetBrainsMonoFamily

private enum class CallFilter(val label: String) {
    ALL("All"),
    SPAM("Spam Risk"),
    BLOCKED("Blocked"),
    VERIFIED("Verified")
}

@Composable
fun CallsScreen(
    profile: UserProfile?,
    calls: List<UnifiedCallRecord>,
    alerts: List<SystemAlert>,
    hasCallLogPermission: Boolean,
    hasCallScreeningRole: Boolean,
    onRequestCallScreeningRole: () -> Unit,
    onRequestPermissions: () -> Unit,
    onRefreshLogs: () -> Unit,
    onInspectNumber: (String) -> Unit,
    onQuickSearchClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf(CallFilter.ALL) }
    var dismissedAlertIds by remember { mutableStateOf(setOf<String>()) }

    val filteredCalls = remember(calls, selectedFilter) {
        when (selectedFilter) {
            CallFilter.ALL -> calls
            CallFilter.SPAM -> calls.filter { it.spamScore >= 35 }
            CallFilter.BLOCKED -> calls.filter { it.isBlocked }
            CallFilter.VERIFIED -> calls.filter { it.verifiedBusiness }
        }
    }

    val visibleAlerts = remember(alerts, dismissedAlertIds) {
        alerts.filter { it.id !in dismissedAlertIds }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ProtectionStatusCard(
                    profile = profile,
                    hasCallScreeningRole = hasCallScreeningRole,
                    hasCallLogPermission = hasCallLogPermission,
                    onRequestCallScreeningRole = onRequestCallScreeningRole,
                    onRequestPermissions = onRequestPermissions,
                    onRefreshLogs = onRefreshLogs
                )
            }

            if (visibleAlerts.isNotEmpty()) {
                items(visibleAlerts.take(2), key = { it.id }) { alert ->
                    SystemAlertBanner(
                        alert = alert,
                        onDismiss = { dismissedAlertIds = dismissedAlertIds + alert.id }
                    )
                }
            }

            item {
                SectionHeader(
                    title = "Recent Calls",
                    actionLabel = "Search Number",
                    onAction = onQuickSearchClick
                )
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CallFilter.entries) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter.label) },
                            modifier = Modifier.testTag("calls_filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }

            if (!hasCallLogPermission && filteredCalls.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "Enable Device Call History",
                        subtitle = "Grant Call Log access to identify recent callers, spot spam trends, and inspect unknown numbers directly from your log.",
                        ctaLabel = stringResource(R.string.grant_permissions),
                        onCta = onRequestPermissions
                    )
                }
            } else if (filteredCalls.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "No Calls in This View",
                        subtitle = "Your screened and recent calls will appear here automatically. Try looking up a number in the Lookup tab.",
                        ctaLabel = "Lookup a Number",
                        onCta = onQuickSearchClick
                    )
                }
            } else {
                items(filteredCalls, key = { it.id }) { record ->
                    CallHistoryRow(
                        record = record,
                        onClick = { onInspectNumber(record.rawNumber) },
                        onDial = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${record.rawNumber}"))
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProtectionStatusCard(
    profile: UserProfile?,
    hasCallScreeningRole: Boolean,
    hasCallLogPermission: Boolean,
    onRequestCallScreeningRole: () -> Unit,
    onRequestPermissions: () -> Unit,
    onRefreshLogs: () -> Unit
) {
    val isActive = profile?.spamProtectionEnabled != false
    val gradientColors by remember(isActive, hasCallScreeningRole) {
        mutableStateOf(
            if (isActive && hasCallScreeningRole) {
                listOf(Color(0xFF0D47A1), Color(0xFF0284C7))
            } else if (isActive) {
                listOf(Color(0xFF1E3A8A), Color(0xFF0369A1))
            } else {
                listOf(Color(0xFF334155), Color(0xFF475569))
            }
        )
    }

    val statusColor by animateColorAsState(
        targetValue = if (isActive && hasCallScreeningRole) Color(0xFF34D399) else Color(0xFFFBBF24),
        label = "shield_status_color"
    )

    Card(
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(gradientColors))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (isActive) Icons.Filled.Shield else Icons.Filled.Warning,
                            contentDescription = "Shield status",
                            tint = statusColor,
                            modifier = Modifier.size(30.dp)
                        )
                        Column {
                            Text(
                                text = when {
                                    !isActive -> "Protection Paused"
                                    hasCallScreeningRole -> "Live Shield Active"
                                    else -> "Setup Call Screening"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (hasCallScreeningRole) {
                                    "STIR/SHAKEN & real-time spam filter enabled"
                                } else {
                                    "Set CallShield as your Caller ID & Spam app"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefreshLogs,
                        modifier = Modifier.testTag("refresh_calls_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh calls",
                            tint = Color.White
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatChip(
                        label = "Screened",
                        value = "${profile?.totalCallsScreened ?: 0}",
                        modifier = Modifier.weight(1f)
                    )
                    StatChip(
                        label = "Blocked",
                        value = "${profile?.totalSpamBlocked ?: 0}",
                        modifier = Modifier.weight(1f)
                    )
                }

                if (!hasCallScreeningRole || !hasCallLogPermission) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!hasCallScreeningRole) {
                            Button(
                                onClick = onRequestCallScreeningRole,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color(0xFF0D47A1)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("enable_caller_id_role_button")
                            ) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Enable Role", maxLines = 1)
                            }
                        }
                        if (!hasCallLogPermission) {
                            OutlinedButton(
                                onClick = onRequestPermissions,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("grant_permissions_button")
                            ) {
                                Text("Grant Access", maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.14f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.88f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFamily),
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
private fun CallHistoryRow(
    record: UnifiedCallRecord,
    onClick: () -> Unit,
    onDial: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("call_row_${record.numberKey}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CallerAvatar(
                name = record.displayName,
                spamScore = record.spamScore,
                verifiedBusiness = record.verifiedBusiness,
                isBlocked = record.isBlocked
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = record.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (record.verifiedBusiness) {
                        VerifiedBusinessPill()
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val dirIcon = when (record.direction) {
                        "OUTGOING" -> Icons.AutoMirrored.Filled.CallMade
                        "MISSED" -> Icons.AutoMirrored.Filled.CallMissed
                        "BLOCKED" -> Icons.Filled.Block
                        else -> Icons.AutoMirrored.Filled.CallReceived
                    }
                    val dirTint = if (record.direction == "MISSED" || record.direction == "BLOCKED") {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Icon(
                        imageVector = dirIcon,
                        contentDescription = record.direction,
                        tint = dirTint,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${record.rawNumber} • ${formatRelativeTime(record.timestampMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                SpamRiskBadge(
                    spamScore = record.spamScore,
                    verifiedBusiness = record.verifiedBusiness,
                    isBlocked = record.isBlocked
                )
            }
            IconButton(
                onClick = onDial,
                modifier = Modifier.testTag("dial_call_${record.numberKey}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = "Call ${record.displayName}",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
