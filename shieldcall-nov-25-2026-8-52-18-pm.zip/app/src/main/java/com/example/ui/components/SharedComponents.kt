package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SystemAlert
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberSoft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallerAvatar(
    name: String,
    spamScore: Int,
    verifiedBusiness: Boolean,
    isBlocked: Boolean,
    modifier: Modifier = Modifier
) {
    val bgColor: Color
    val fgColor: Color
    when {
        isBlocked || spamScore >= 70 -> {
            bgColor = MaterialTheme.colorScheme.errorContainer
            fgColor = MaterialTheme.colorScheme.onErrorContainer
        }
        verifiedBusiness -> {
            bgColor = MaterialTheme.colorScheme.tertiaryContainer
            fgColor = MaterialTheme.colorScheme.onTertiaryContainer
        }
        spamScore >= 35 -> {
            bgColor = WarningAmberSoft
            fgColor = WarningAmber
        }
        else -> {
            bgColor = MaterialTheme.colorScheme.primaryContainer
            fgColor = MaterialTheme.colorScheme.onPrimaryContainer
        }
    }

    Box(
        modifier = modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        when {
            isBlocked -> Icon(
                imageVector = Icons.Filled.Block,
                contentDescription = "Blocked caller",
                tint = fgColor,
                modifier = Modifier.size(22.dp)
            )
            spamScore >= 70 -> Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = "High spam risk",
                tint = fgColor,
                modifier = Modifier.size(22.dp)
            )
            verifiedBusiness -> Icon(
                imageVector = Icons.Filled.Verified,
                contentDescription = "Verified business",
                tint = fgColor,
                modifier = Modifier.size(22.dp)
            )
            else -> {
                val initials = name.trim()
                    .split(" ")
                    .filter { it.isNotBlank() }
                    .take(2)
                    .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                    .joinToString("")
                    .ifBlank { "#" }
                Text(
                    text = initials,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = fgColor
                )
            }
        }
    }
}

@Composable
fun SpamRiskBadge(
    spamScore: Int,
    verifiedBusiness: Boolean,
    isBlocked: Boolean,
    modifier: Modifier = Modifier
) {
    val (label, containerColor, contentColor) = when {
        isBlocked -> Triple(
            "Blocked",
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.onErrorContainer
        )
        verifiedBusiness -> Triple(
            "Verified",
            MaterialTheme.colorScheme.tertiaryContainer,
            MaterialTheme.colorScheme.onTertiaryContainer
        )
        spamScore >= 70 -> Triple(
            "Spam $spamScore%",
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.onErrorContainer
        )
        spamScore >= 35 -> Triple(
            "Risk $spamScore%",
            WarningAmberSoft,
            WarningAmber
        )
        else -> Triple(
            "Safe",
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer
        )
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = containerColor
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun VerifiedBusinessPill(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Verified,
                contentDescription = stringResource(R.string.verified_business_badge),
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = "Verified",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
    }
}

@Composable
fun SystemAlertBanner(
    alert: SystemAlert,
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isCritical = alert.severity == "CRITICAL"
    val isWarning = alert.severity == "WARNING"
    val container = when {
        isCritical -> MaterialTheme.colorScheme.errorContainer
        isWarning -> WarningAmberSoft
        else -> MaterialTheme.colorScheme.primaryContainer
    }
    val content = when {
        isCritical -> MaterialTheme.colorScheme.onErrorContainer
        isWarning -> WarningAmber
        else -> MaterialTheme.colorScheme.onPrimaryContainer
    }

    AnimatedVisibility(visible = true, enter = fadeIn(), exit = fadeOut()) {
        Card(
            modifier = modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = container)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = if (isCritical || isWarning) Icons.Filled.Warning else Icons.Filled.Campaign,
                    contentDescription = "Security alert",
                    tint = content,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = alert.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = content
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = alert.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = content.copy(alpha = 0.9f)
                    )
                }
                if (onDismiss != null) {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Dismiss alert",
                            tint = content
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    title: String,
    subtitle: String,
    ctaLabel: String? = null,
    onCta: (() -> Unit)? = null,
    showIllustration: Boolean = true,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (showIllustration) {
                Image(
                    painter = painterResource(id = R.drawable.img_empty_safe),
                    contentDescription = stringResource(R.string.cd_empty_shield),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .size(132.dp)
                        .clip(RoundedCornerShape(18.dp))
                )
                Spacer(modifier = Modifier.height(14.dp))
            } else {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = stringResource(R.string.cd_empty_shield),
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (ctaLabel != null && onCta != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onCta) {
                    Text(ctaLabel)
                }
            }
        }
    }
}

fun formatRelativeTime(millis: Long): String {
    if (millis <= 0L) return "Recently"
    val diff = System.currentTimeMillis() - millis
    return when {
        diff < 60_000L -> "Just now"
        diff < 3_600_000L -> "${diff / 60_000L}m ago"
        diff < 86_400_000L -> "${diff / 3_600_000L}h ago"
        else -> SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(millis))
    }
}
