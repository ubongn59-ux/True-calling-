package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AdminMember
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.CallerRating
import com.example.data.model.SpamReport
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedBusiness
import com.example.util.OperationType
import com.example.util.PhoneNumberNormalizer
import com.example.util.handleFirestoreError
import com.example.util.unwrapFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class DirectoryAdminRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observePublicDirectory(userId: String): Flow<List<CallerDirectoryEntry>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "caller_directory"
        emitAll(
            db.collection("caller_directory")
                .whereEqualTo("visibility", "PUBLIC")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallerDirectoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.spamScore }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun getDirectoryEntry(numberKey: String): Result<CallerDirectoryEntry?> {
        val path = "caller_directory/$numberKey"
        return try {
            requireUserId()
            require(numberKey.length in 3..24) { "Invalid phone number key" }
            val snap = db.collection("caller_directory").document(numberKey).get().await()
            val entry = snap.toObject(CallerDirectoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(entry)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    fun observeRatingsForNumber(userId: String, numberKey: String): Flow<List<CallerRating>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "caller_ratings"
        emitAll(
            db.collection("caller_ratings")
                .whereEqualTo("visibility", "PUBLIC")
                .whereEqualTo("numberKey", numberKey)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallerRating::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeApprovedReportsForNumber(userId: String, numberKey: String): Flow<List<SpamReport>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "spam_reports"
        emitAll(
            db.collection("spam_reports")
                .whereEqualTo("status", "APPROVED")
                .whereEqualTo("numberKey", numberKey)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(SpamReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMySpamReports(userId: String): Flow<List<SpamReport>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "spam_reports"
        emitAll(
            db.collection("spam_reports")
                .whereEqualTo("reporterId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(SpamReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun submitSpamReport(
        reporterName: String,
        rawNumber: String,
        reportedName: String,
        category: String,
        comment: String
    ): Result<Unit> {
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        val reportPath = "spam_reports"
        return try {
            val uid = requireUserId()
            require(numberKey.length in 3..24) { "Enter a valid phone number." }
            val displayNumber = PhoneNumberNormalizer.formatDisplay(rawNumber).take(30)
            val safeCategory = if (category in REPORT_CATEGORIES) category else "SCAM_FRAUD"
            val cleanReportedName = reportedName.trim().take(80)
            val cleanComment = comment.trim().take(300)
            val safeReporterName = reporterName.trim().take(80).ifBlank { "Community Member" }

            val reportRef = db.collection("spam_reports").document()
            reportRef.set(
                mapOf(
                    "reporterId" to uid,
                    "reporterName" to safeReporterName,
                    "numberKey" to numberKey,
                    "displayNumber" to displayNumber,
                    "reportedName" to cleanReportedName,
                    "category" to safeCategory,
                    "comment" to cleanComment,
                    "status" to "PENDING",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // Sync or initialize caller_directory entry
            val dirRef = db.collection("caller_directory").document(numberKey)
            val existingDir = dirRef.get().await()
            val isSafeVote = safeCategory == "SAFE"

            if (!existingDir.exists()) {
                val initialScore = if (isSafeVote) 5L else 65L
                val callerLabel = cleanReportedName.ifBlank {
                    if (isSafeVote) "Safe Caller" else "Reported $safeCategory"
                }.take(80)
                dirRef.set(
                    mapOf(
                        "numberKey" to numberKey,
                        "displayNumber" to displayNumber,
                        "callerName" to callerLabel,
                        "category" to safeCategory,
                        "verifiedBusiness" to false,
                        "visibility" to "PUBLIC",
                        "spamReportsCount" to if (isSafeVote) 0L else 1L,
                        "safeReportsCount" to if (isSafeVote) 1L else 0L,
                        "spamScore" to initialScore,
                        "averageRating" to 0.0,
                        "ratingsCount" to 0L,
                        "lastReportedTag" to safeCategory.take(60),
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val currentSpam = existingDir.getLong("spamReportsCount") ?: 0L
                val currentSafe = existingDir.getLong("safeReportsCount") ?: 0L
                val newSpam = if (isSafeVote) currentSpam else currentSpam + 1L
                val newSafe = if (isSafeVote) currentSafe + 1L else currentSafe
                val total = (newSpam + newSafe).coerceAtLeast(1L)
                val newScore = ((newSpam.toDouble() / total.toDouble()) * 100.0)
                    .toLong()
                    .coerceIn(0L, 100L)
                val existingName = existingDir.getString("callerName").orEmpty()
                val nextName = if (cleanReportedName.isNotBlank() && existingName.startsWith("Reported ")) {
                    cleanReportedName
                } else {
                    existingName.ifBlank { cleanReportedName.ifBlank { displayNumber } }
                }.take(80)

                dirRef.update(
                    mapOf(
                        "callerName" to nextName,
                        "category" to safeCategory,
                        "spamReportsCount" to newSpam,
                        "safeReportsCount" to newSafe,
                        "spamScore" to newScore,
                        "lastReportedTag" to safeCategory.take(60),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, reportPath)
            Result.failure(e)
        }
    }

    suspend fun submitCallerRating(
        userName: String,
        rawNumber: String,
        stars: Int,
        review: String
    ): Result<Unit> {
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        val path = "caller_ratings"
        return try {
            val uid = requireUserId()
            require(numberKey.length in 3..24) { "Invalid phone number." }
            val safeStars = stars.coerceIn(1, 5).toLong()
            val cleanReview = review.trim().take(280)
            val safeUserName = userName.trim().take(80).ifBlank { "Community Member" }
            val ratingId = "${numberKey}_$uid"
            val ratingRef = db.collection("caller_ratings").document(ratingId)
            val existingRating = ratingRef.get().await()

            if (existingRating.exists()) {
                ratingRef.update(
                    mapOf(
                        "stars" to safeStars,
                        "review" to cleanReview,
                        "userName" to safeUserName,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ratingRef.set(
                    mapOf(
                        "userId" to uid,
                        "userName" to safeUserName,
                        "numberKey" to numberKey,
                        "stars" to safeStars,
                        "review" to cleanReview,
                        "visibility" to "PUBLIC",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            // Recompute average rating for directory entry
            val ratingsSnap = db.collection("caller_ratings")
                .whereEqualTo("visibility", "PUBLIC")
                .whereEqualTo("numberKey", numberKey)
                .get()
                .await()
            val allRatings = ratingsSnap.toObjects(CallerRating::class.java)
            val count = allRatings.size.toLong()
            val avg = if (count > 0) allRatings.map { it.stars }.average().coerceIn(0.0, 5.0) else safeStars.toDouble()

            val dirRef = db.collection("caller_directory").document(numberKey)
            val dirSnap = dirRef.get().await()
            val displayNumber = PhoneNumberNormalizer.formatDisplay(rawNumber).take(30)
            if (!dirSnap.exists()) {
                dirRef.set(
                    mapOf(
                        "numberKey" to numberKey,
                        "displayNumber" to displayNumber,
                        "callerName" to displayNumber,
                        "category" to "COMMUNITY",
                        "verifiedBusiness" to false,
                        "visibility" to "PUBLIC",
                        "spamReportsCount" to 0L,
                        "safeReportsCount" to 0L,
                        "spamScore" to 0L,
                        "averageRating" to avg,
                        "ratingsCount" to count,
                        "lastReportedTag" to "RATED",
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                dirRef.update(
                    mapOf(
                        "averageRating" to avg,
                        "ratingsCount" to count,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeVerifiedBusinesses(userId: String): Flow<List<VerifiedBusiness>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "verified_businesses"
        emitAll(
            db.collection("verified_businesses")
                .whereEqualTo("verificationStatus", "VERIFIED")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(VerifiedBusiness::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.businessName.lowercase() }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMyBusinessApplications(userId: String): Flow<List<VerifiedBusiness>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "verified_businesses"
        emitAll(
            db.collection("verified_businesses")
                .whereEqualTo("ownerId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(VerifiedBusiness::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun submitBusinessVerification(
        businessName: String,
        rawNumber: String,
        category: String,
        website: String,
        description: String
    ): Result<Unit> {
        val path = "verified_businesses"
        return try {
            val uid = requireUserId()
            val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
            require(numberKey.length in 3..24) { "Enter a valid business phone number." }
            val cleanName = businessName.trim().take(80)
            require(cleanName.length >= 2) { "Business name must be at least 2 characters." }
            val cleanCategory = category.trim().take(40).ifBlank { "Business" }
            require(cleanCategory.length >= 2) { "Category must be at least 2 characters." }

            val docRef = db.collection("verified_businesses").document()
            docRef.set(
                mapOf(
                    "ownerId" to uid,
                    "businessName" to cleanName,
                    "numberKey" to numberKey,
                    "displayNumber" to PhoneNumberNormalizer.formatDisplay(rawNumber).take(30),
                    "category" to cleanCategory,
                    "website" to website.trim().take(120),
                    "description" to description.trim().take(300),
                    "verificationStatus" to "PENDING",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // ---------------- ADMIN DASHBOARD OPERATIONS ----------------

    fun observePendingReportsAdmin(userId: String): Flow<List<SpamReport>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        emitAll(
            db.collection("spam_reports")
                .whereEqualTo("status", "PENDING")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(SpamReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, "spam_reports")
                    }
                    throw error
                }
        )
    }

    fun observePendingBusinessesAdmin(userId: String): Flow<List<VerifiedBusiness>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        emitAll(
            db.collection("verified_businesses")
                .whereEqualTo("verificationStatus", "PENDING")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(VerifiedBusiness::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, "verified_businesses")
                    }
                    throw error
                }
        )
    }

    fun observeAllUsersAdmin(userId: String): Flow<List<UserProfile>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, "users")
                    }
                    throw error
                }
        )
    }

    fun observeAdminsList(userId: String): Flow<List<AdminMember>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        emitAll(
            db.collection("admins")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(AdminMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.displayName.lowercase() }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, "admins")
                    }
                    throw error
                }
        )
    }

    suspend fun moderateReport(report: SpamReport, approve: Boolean): Result<Unit> {
        val path = "spam_reports/${report.id}"
        return try {
            val adminUid = requireUserId()
            require(report.id.isNotBlank()) { "Report ID missing" }
            val nextStatus = if (approve) "APPROVED" else "REJECTED"
            db.collection("spam_reports").document(report.id).update(
                mapOf(
                    "status" to nextStatus,
                    "reviewedBy" to adminUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (approve) {
                val dirRef = db.collection("caller_directory").document(report.numberKey)
                val dirSnap = dirRef.get().await()
                if (dirSnap.exists()) {
                    val isSafe = report.category == "SAFE"
                    val currentScore = dirSnap.getLong("spamScore") ?: 50L
                    val adjustedScore = if (isSafe) (currentScore - 25L).coerceAtLeast(0L) else (currentScore + 15L).coerceAtMost(100L)
                    val updates = mutableMapOf<String, Any>(
                        "spamScore" to adjustedScore,
                        "lastReportedTag" to report.category.take(60),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    if (report.reportedName.isNotBlank()) {
                        updates["callerName"] = report.reportedName.take(80)
                    }
                    dirRef.update(updates).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun moderateBusiness(business: VerifiedBusiness, approve: Boolean): Result<Unit> {
        val path = "verified_businesses/${business.id}"
        return try {
            val adminUid = requireUserId()
            require(business.id.isNotBlank()) { "Business ID missing" }
            val nextStatus = if (approve) "VERIFIED" else "REJECTED"
            db.collection("verified_businesses").document(business.id).update(
                mapOf(
                    "verificationStatus" to nextStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (approve) {
                val dirRef = db.collection("caller_directory").document(business.numberKey)
                val dirSnap = dirRef.get().await()
                if (dirSnap.exists()) {
                    dirRef.update(
                        mapOf(
                            "callerName" to business.businessName.take(80),
                            "category" to "VERIFIED_BUSINESS",
                            "verifiedBusiness" to true,
                            "visibility" to "PUBLIC",
                            "spamScore" to 0L,
                            "lastReportedTag" to "VERIFIED",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } else {
                    dirRef.set(
                        mapOf(
                            "numberKey" to business.numberKey,
                            "displayNumber" to business.displayNumber,
                            "callerName" to business.businessName.take(80),
                            "category" to "VERIFIED_BUSINESS",
                            "verifiedBusiness" to true,
                            "visibility" to "PUBLIC",
                            "spamReportsCount" to 0L,
                            "safeReportsCount" to 1L,
                            "spamScore" to 0L,
                            "averageRating" to 5.0,
                            "ratingsCount" to 0L,
                            "lastReportedTag" to "VERIFIED",
                            "createdBy" to adminUid,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminUpsertDirectoryEntry(
        rawNumber: String,
        callerName: String,
        category: String,
        spamScore: Int,
        verifiedBusiness: Boolean,
        visibility: String
    ): Result<Unit> {
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        val path = "caller_directory/$numberKey"
        return try {
            val adminUid = requireUserId()
            require(numberKey.length in 3..24) { "Invalid phone number." }
            val cleanName = callerName.trim().take(80)
            require(cleanName.isNotEmpty()) { "Caller name cannot be empty." }
            val safeCategory = if (category in ALL_DIRECTORY_CATEGORIES) category else "COMMUNITY"
            val safeVisibility = if (visibility in listOf("PUBLIC", "HIDDEN")) visibility else "PUBLIC"
            val safeScore = spamScore.coerceIn(0, 100).toLong()

            val dirRef = db.collection("caller_directory").document(numberKey)
            val snap = dirRef.get().await()
            if (snap.exists()) {
                dirRef.update(
                    mapOf(
                        "callerName" to cleanName,
                        "category" to safeCategory,
                        "verifiedBusiness" to verifiedBusiness,
                        "visibility" to safeVisibility,
                        "spamScore" to safeScore,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                dirRef.set(
                    mapOf(
                        "numberKey" to numberKey,
                        "displayNumber" to PhoneNumberNormalizer.formatDisplay(rawNumber).take(30),
                        "callerName" to cleanName,
                        "category" to safeCategory,
                        "verifiedBusiness" to verifiedBusiness,
                        "visibility" to safeVisibility,
                        "spamReportsCount" to if (safeScore >= 50L) 1L else 0L,
                        "safeReportsCount" to if (safeScore < 50L) 1L else 0L,
                        "spamScore" to safeScore,
                        "averageRating" to if (verifiedBusiness) 5.0 else 0.0,
                        "ratingsCount" to 0L,
                        "lastReportedTag" to safeCategory.take(60),
                        "createdBy" to adminUid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminDeleteDirectoryEntry(numberKey: String): Result<Unit> {
        val path = "caller_directory/$numberKey"
        return try {
            requireUserId()
            db.collection("caller_directory").document(numberKey).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun publishSystemAlert(title: String, message: String, severity: String): Result<Unit> {
        val path = "system_alerts"
        return try {
            val adminUid = requireUserId()
            val cleanTitle = title.trim().take(80)
            val cleanMessage = message.trim().take(300)
            require(cleanTitle.length >= 2) { "Alert title must be at least 2 characters." }
            require(cleanMessage.length >= 2) { "Alert message must be at least 2 characters." }
            val safeSeverity = if (severity in listOf("INFO", "WARNING", "CRITICAL")) severity else "INFO"

            db.collection("system_alerts").document().set(
                mapOf(
                    "title" to cleanTitle,
                    "message" to cleanMessage,
                    "severity" to safeSeverity,
                    "targetScope" to "ALL_USERS",
                    "createdBy" to adminUid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteSystemAlert(alertId: String): Result<Unit> {
        val path = "system_alerts/$alertId"
        return try {
            requireUserId()
            db.collection("system_alerts").document(alertId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun grantAdminRole(targetUid: String, email: String, displayName: String): Result<Unit> {
        val cleanUid = targetUid.trim()
        val path = "admins/$cleanUid"
        return try {
            val adminUid = requireUserId()
            require(cleanUid.matches(Regex("^[a-zA-Z0-9_\\-]+$"))) { "Invalid UID format." }
            val cleanEmail = email.trim().take(120)
            val cleanName = displayName.trim().take(80).ifBlank { "Admin" }
            require(cleanEmail.length >= 3) { "Valid email is required." }

            db.collection("admins").document(cleanUid).set(
                mapOf(
                    "uid" to cleanUid,
                    "email" to cleanEmail,
                    "displayName" to cleanName,
                    "grantedBy" to adminUid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val userRef = db.collection("users").document(cleanUid)
            if (userRef.get().await().exists()) {
                userRef.update(
                    mapOf(
                        "role" to "ADMIN",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun revokeAdminRole(targetUid: String): Result<Unit> {
        val path = "admins/$targetUid"
        return try {
            requireUserId()
            db.collection("admins").document(targetUid).delete().await()
            val userRef = db.collection("users").document(targetUid)
            if (userRef.get().await().exists()) {
                userRef.update(
                    mapOf(
                        "role" to "USER",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    companion object {
        val REPORT_CATEGORIES = listOf(
            "SCAM_FRAUD",
            "ROBOCALL",
            "TELEMARKETER",
            "PHISHING",
            "IMPERSONATION",
            "SAFE"
        )

        val ALL_DIRECTORY_CATEGORIES = listOf(
            "VERIFIED_BUSINESS",
            "TELEMARKETER",
            "SCAM_FRAUD",
            "ROBOCALL",
            "DELIVERY",
            "SUPPORT",
            "COMMUNITY",
            "PHISHING",
            "IMPERSONATION",
            "SAFE"
        )
    }
}
